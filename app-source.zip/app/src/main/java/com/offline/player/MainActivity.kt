package com.offline.player

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.ripple.LocalRippleTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { PlayerApp() }
    }
}

@Composable
fun PlayerApp() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val app = remember { AppState(prefs, PlaylistStore(prefs.raw), PlayerState()) }
    val ps = app.ps
    val scope = rememberCoroutineScope()

    var granted by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf(false) }
    var visible by remember { mutableStateOf(true) }
    var tab by rememberSaveable { mutableStateOf(0) }          // 0 Home, 1 My Music, 2 Settings
    var homeChip by rememberSaveable { mutableStateOf(0) }
    var musicChip by rememberSaveable { mutableStateOf(0) }
    var searchOn by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var showNow by rememberSaveable { mutableStateOf(false) }
    var showQueue by rememberSaveable { mutableStateOf(false) }
    var detail by remember { mutableStateOf<Detail?>(null) }
    var showSleep by remember { mutableStateOf(false) }
    var sleepEnd by remember { mutableLongStateOf(0L) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var restored by remember { mutableStateOf(false) }

    // ── permissions & library ──
    val perms = if (Build.VERSION.SDK_INT >= 33)
        arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    fun hasPerm() = ContextCompat.checkSelfPermission(ctx, perms[0]) == PackageManager.PERMISSION_GRANTED
    fun reload() { scope.launch { app.setSongs(withContext(Dispatchers.IO) { loadSongs(ctx) }); loaded = true } }
    val openAppSettings = {
        ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null)))
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasPerm()
        if (granted) reload()
    }
    LaunchedEffect(Unit) {
        if (hasPerm()) { granted = true; reload() } else launcher.launch(perms)
    }

    // ── lifecycle: pause polling when hidden, persist session, pick up permission granted in system settings ──
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_START -> { visible = true; if (!granted && hasPerm()) { granted = true; reload() } }
                Lifecycle.Event.ON_STOP -> { visible = false; saveSession(ps, prefs) }
                else -> {}
            }
        }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }

    // ── connect to the playback service ──
    DisposableEffect(Unit) {
        val future = MediaController.Builder(ctx, SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))).buildAsync()
        future.addListener({
            val c = try { future.get() } catch (e: Exception) { return@addListener }
            ps.controller = c
            c.addListener(object : Player.Listener {
                override fun onEvents(pl: Player, e: Player.Events) {
                    ps.sync(pl, e.contains(Player.EVENT_TIMELINE_CHANGED))
                    if (e.containsAny(Player.EVENT_MEDIA_ITEM_TRANSITION, Player.EVENT_IS_PLAYING_CHANGED) && !pl.isPlaying) saveSession(ps, prefs)
                    else if (e.contains(Player.EVENT_MEDIA_ITEM_TRANSITION)) saveSession(ps, prefs)
                }
            })
            ps.sync(c, true)
        }, ContextCompat.getMainExecutor(ctx))
        onDispose { MediaController.releaseFuture(future); ps.controller = null }
    }

    // ── restore last session (paused) once both library and controller are ready ──
    LaunchedEffect(ps.controller, app.songs) {
        val c = ps.controller ?: return@LaunchedEffect
        if (restored || !loaded) return@LaunchedEffect
        restored = true
        if (c.mediaItemCount > 0) return@LaunchedEffect
        val ids = prefs.sessionIds()
        val items = ids.mapNotNull { app.byId[it] }
        if (items.isEmpty()) return@LaunchedEffect
        val curId = ids.getOrNull(prefs.sessionIdx())
        val start = items.indexOfFirst { it.id == curId }
        c.setMediaItems(items.map { it.toItem() }, start.coerceAtLeast(0), if (start >= 0) prefs.sessionPos() else 0L)
        c.prepare()
    }

    // ── position polling (only while the UI is visible) ──
    LaunchedEffect(ps.controller, visible) {
        while (visible) {
            ps.controller?.let { ps.pos = it.currentPosition; ps.dur = it.duration.coerceAtLeast(0) }
            delay(if (ps.playing) 400 else 1000)
        }
    }
    LaunchedEffect(ps.controller) {
        var counted = ""
        while (true) {
            val c = ps.controller
            if (c != null && c.isPlaying) {
                val id = c.currentMediaItem?.mediaId
                val d = c.duration
                val need = if (d > 0) minOf(30_000L, d / 2) else 30_000L
                if (id != null) {
                    if (c.currentPosition < 2_000L && counted == id) counted = ""
                    if (counted != id && c.currentPosition >= need) { id.toLongOrNull()?.let { prefs.addPlay(it) }; counted = id }
                }
            }
            delay(3_000)
        }
    }
    LaunchedEffect(ps.controller, prefs.speed) { ps.controller?.setPlaybackSpeed(speeds[prefs.speed]) }
    LaunchedEffect(sleepEnd) {
        while (sleepEnd > System.currentTimeMillis()) { now = System.currentTimeMillis(); delay(1000) }
        if (sleepEnd > 0) { ps.controller?.pause(); sleepEnd = 0 }
    }

    // ── search + sort off the main thread, debounced ──
    val sortMode = prefs.sort
    val sorted by produceState(emptyList<Song>(), app.songs, sortMode) {
        value = withContext(Dispatchers.Default) { sortSongs(app.songs, sortMode) }
    }
    val results by produceState(emptyList<Song>(), sorted, query) {
        if (query.isNotBlank()) delay(150)
        val q = query.trim().lowercase()
        value = withContext(Dispatchers.Default) { if (q.isEmpty()) sorted else sorted.filter { it.key.contains(q) } }
    }

    // ── artwork-derived palette ──
    val item = ps.current
    var pal by remember { mutableStateOf<ArtPalette?>(null) }
    LaunchedEffect(item?.mediaId, prefs.dynamic) {
        pal = if (prefs.dynamic && item != null) artPalette(ctx, item.mediaMetadata.artworkUri) else null
    }

    var device by remember { mutableStateOf<AudioOut?>(null) }
    var deviceVisible by remember { mutableStateOf(false) }
    AudioOutputWatcher { device = it }
    LaunchedEffect(device) { if (device != null) { deviceVisible = true; delay(4500); deviceVisible = false } }
    val motion = prefs.motion
    val baseAccent = Accents[prefs.accent].second
    val accent = animColor(pal?.accent ?: baseAccent, motion)
    val base = uiColors(prefs.mode, accent)
    val tint = pal != null && prefs.mode == 0
    val top = animColor(if (tint) lerp(base.top, pal!!.top, .45f) else base.top, motion)
    val mid = animColor(if (tint) lerp(base.mid, pal!!.mid, .45f) else base.mid, motion)
    val bottom = animColor(if (tint) lerp(base.bottom, pal!!.bottom, .45f) else base.bottom, motion)
    val ui = uiColors(prefs.mode, accent, top, bottom, mid)
    // Now Playing is always an immersive dark surface tinted by the cover, whatever the app theme.
    val npBase = uiColors(if (prefs.mode == 1) 1 else 0, accent)
    val npTop = animColor(pal?.top ?: npBase.top, motion)
    val npMid = animColor(pal?.mid ?: npBase.mid, motion)
    val npBottom = animColor(pal?.bottom ?: npBase.bottom, motion)
    val npUi = uiColors(if (prefs.mode == 1) 1 else 0, accent, npTop, npBottom, npMid)

    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window ?: return@SideEffect
        val light = ui.light && !showNow
        WindowCompat.getInsetsController(w, view).apply { isAppearanceLightStatusBars = light; isAppearanceLightNavigationBars = light }
    }

    val scheme = if (ui.light) lightColorScheme(primary = ui.accent, onPrimary = ui.onAccent, surface = Color.White, onSurface = ui.text)
    else darkColorScheme(primary = ui.accent, onPrimary = ui.onAccent, surface = Color(0xFF1E1E2A), onSurface = ui.text)
    val sleepLabel = if (sleepEnd > now) "Sleep " + fmt(sleepEnd - now) else "Sleep timer"

    BackHandler(tab != 0) { tab = 0 }
    BackHandler(detail != null) { detail = null }
    BackHandler(showNow) { showNow = false }
    BackHandler(showQueue) { showQueue = false }

    val enter = when (motion) { 0 -> slideInVertically(tween(350)) { it / 3 } + fadeIn(tween(250)); 1 -> fadeIn(tween(120)); else -> EnterTransition.None }
    val exit = when (motion) { 0 -> slideOutVertically(tween(300)) { it / 3 } + fadeOut(tween(200)); 1 -> fadeOut(tween(120)); else -> ExitTransition.None }

    CompositionLocalProvider(
        LocalUi provides ui, LocalArtShape provides prefs.artShape, LocalMotion provides motion,
        LocalContentColor provides ui.text,
        LocalRippleTheme provides FrRipple(if (ui.light) ui.accent else ui.accentText)
    ) {
        MaterialTheme(colorScheme = scheme) {
            Box(Modifier.fillMaxSize().background(uiBrush(ui))) {
                if (prefs.wallpaperRev > 0) {
                    AsyncImage(prefs.wallpaperFile.takeIf { prefs.wallpaperRev > 0 }, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(ui.top.copy(alpha = if (ui.light) .55f else .72f)))
                }

                Column(Modifier.fillMaxSize().statusBarsPadding()) {
                    Box(Modifier.weight(1f)) {
                        val d = detail
                        if (d != null) DetailScreen(app, d) { detail = null }
                        else when (tab) {
                            0 -> HomeScreen(
                                app, homeChip, { homeChip = it }, loaded, granted,
                                { launcher.launch(perms) }, openAppSettings,
                                { detail = it },
                                { tab = 1; searchOn = true; musicChip = 0 },
                                { tab = 1; musicChip = 5 },
                                { tab = 2 }
                            )
                            1 -> MyMusicScreen(
                                app, results, query, { query = it }, musicChip, { musicChip = it },
                                searchOn, { searchOn = !searchOn; if (!searchOn) query = "" },
                                loaded, granted, { launcher.launch(perms) }, openAppSettings,
                                { tab = 0 }, { musicChip = if (musicChip == 5) 0 else 5 }, { detail = it }
                            )
                            3 -> OnlineScreen(app)
                            else -> SettingsScreen(app) { if (granted) reload() }
                        }
                    }
                    MiniPlayer(app) { showNow = true }
                    Box(Modifier.navigationBarsPadding()) { FloatNav(tab) { tab = it; detail = null } }
                }

                AnimatedVisibility(showNow && item != null, enter = enter, exit = exit) {
                    CompositionLocalProvider(LocalUi provides npUi, LocalContentColor provides npUi.text) {
                        Box(Modifier.fillMaxSize().background(uiBrush(npUi))) {
                            if (prefs.blur) item?.let {
                                AsyncImage(it.mediaMetadata.artworkUri, null, Modifier.fillMaxSize().blur(48.dp), alpha = .28f, contentScale = ContentScale.Crop)
                            }
                            NowPlaying(app, sleepLabel, { showSleep = true }, { showQueue = true }, { showNow = false })
                        }
                    }
                }
                AnimatedVisibility(showQueue, enter = enter, exit = exit) {
                    CompositionLocalProvider(LocalUi provides npUi, LocalContentColor provides npUi.text) {
                        Box(Modifier.fillMaxSize().background(uiBrush(npUi))) {
                            QueueScreen(app) { showQueue = false }
                        }
                    }
                }

                AnimatedVisibility(
                    deviceVisible, modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 84.dp),
                    enter = enter, exit = exit
                ) { device?.let { DeviceCard(it) { deviceVisible = false } } }

                AddToPlaylistDialog(app)
                if (showSleep) AlertDialog(
                    onDismissRequest = { showSleep = false }, confirmButton = {},
                    containerColor = if (ui.light) Color.White else Color(0xFF1E1E2A),
                    title = { Text("Sleep timer", color = ui.text) },
                    text = {
                        Column {
                            listOf(15, 30, 45, 60).forEach { m ->
                                TextButton({ sleepEnd = System.currentTimeMillis() + m * 60000L; now = System.currentTimeMillis(); showSleep = false }) { Text("$m minutes", color = ui.text) }
                            }
                            TextButton({ sleepEnd = 0; showSleep = false }) { Text("Turn off timer", color = ui.accentText) }
                        }
                    }
                )
            }
        }
    }
}
