package com.offline.player

import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ───────────────────────── Dialogs ─────────────────────────

@Composable
private fun dialogColor(): Color = if (LocalUi.current.light) Color.White else Color(0xFF1E1E2A)

@Composable
fun ConfirmDialog(title: String, text: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val u = LocalUi.current
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = dialogColor(), titleContentColor = u.text, textContentColor = u.dim,
        title = { Text(title) }, text = { Text(text) },
        confirmButton = { TextButton(onConfirm) { Text(confirm, color = u.accentText) } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel", color = u.dim) } }
    )
}

@Composable
fun NameDialog(title: String, initial: String, confirm: String = "Save", onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    val u = LocalUi.current
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = dialogColor(), titleContentColor = u.text,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                name, { name = it.take(60) }, singleLine = true, label = { Text("Name") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = u.text, unfocusedTextColor = u.text, cursorColor = u.accent,
                    focusedBorderColor = u.accent, unfocusedBorderColor = u.border,
                    focusedLabelColor = u.accentText, unfocusedLabelColor = u.dim
                )
            )
        },
        confirmButton = { TextButton({ if (name.isNotBlank()) onConfirm(name) }, enabled = name.isNotBlank()) { Text(confirm, color = u.accentText) } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel", color = u.dim) } }
    )
}

@Composable
fun AddToPlaylistDialog(app: AppState) {
    val songs = app.pickFor ?: return
    val u = LocalUi.current
    val ctx = LocalContext.current
    var creating by remember { mutableStateOf(false) }
    val label = if (songs.size == 1) "“${songs[0].title}”" else "${songs.size} tracks"
    if (creating) {
        NameDialog("New playlist", "", "Create", { name ->
            app.pls.create(name, songs.map { it.id })
            Toast.makeText(ctx, "Added $label to $name", Toast.LENGTH_SHORT).show()
            creating = false; app.pickFor = null
        }, { creating = false })
        return
    }
    AlertDialog(
        onDismissRequest = { app.pickFor = null }, containerColor = dialogColor(), titleContentColor = u.text,
        title = { Text("Add to playlist") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                TextButton({ creating = true }, Modifier.fillMaxWidth()) { Text("＋ New playlist…", color = u.accentText) }
                app.pls.lists.forEach { pl ->
                    TextButton({
                        val n = app.pls.add(pl.id, songs.map { it.id })
                        Toast.makeText(ctx, if (n == 0) "Already in ${pl.name}" else "Added $n to ${pl.name}", Toast.LENGTH_SHORT).show()
                        app.pickFor = null
                    }, Modifier.fillMaxWidth()) { Text("${pl.name}  ·  ${pl.songIds.size}", color = u.text, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton({ app.pickFor = null }) { Text("Cancel", color = u.dim) } }
    )
}

/** Multi-select picker used to add several tracks to a playlist at once. */
@Composable
fun SongPickerDialog(app: AppState, existing: Set<Long>, onAdd: (List<Long>) -> Unit, onDismiss: () -> Unit) {
    val u = LocalUi.current
    var q by remember { mutableStateOf("") }
    var sel by remember { mutableStateOf(setOf<Long>()) }
    val all = remember(app.songs, existing) { sortSongs(app.songs.filter { it.id !in existing }, 0) }
    val shown = remember(all, q) { val k = q.trim().lowercase(); if (k.isEmpty()) all else all.filter { it.key.contains(k) } }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = dialogColor(), titleContentColor = u.text,
        title = { Text("Add songs") },
        text = {
            Column {
                SearchField(q, { q = it })
                Spacer(Modifier.height(8.dp))
                if (shown.isEmpty()) Text("No songs to add.", color = u.dim)
                LazyColumn(Modifier.heightIn(max = 340.dp)) {
                    items(shown, key = { it.id }) { s ->
                        val on = s.id in sel
                        Row(
                            Modifier.fillMaxWidth().clickable(onClickLabel = if (on) "Deselect ${s.title}" else "Select ${s.title}") {
                                sel = if (on) sel - s.id else sel + s.id
                            }.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(on, null, colors = CheckboxDefaults.colors(checkedColor = u.accent, checkmarkColor = u.onAccent, uncheckedColor = u.dim))
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, color = u.text)
                                Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = u.dim)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton({ onAdd(sel.toList()) }, enabled = sel.isNotEmpty()) { Text("Add ${sel.size}", color = u.accentText) } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel", color = u.dim) } }
    )
}

// ───────────────────────── Shared building blocks ─────────────────────────

@Composable
fun SearchField(q: String, onQ: (String) -> Unit, modifier: Modifier = Modifier) {
    val u = LocalUi.current
    OutlinedTextField(
        q, onQ, modifier.fillMaxWidth(), singleLine = true,
        placeholder = { Text("Search title, artist or album", color = u.dim) },
        leadingIcon = { Ico(P.Search, u.dim) },
        trailingIcon = { if (q.isNotEmpty()) IconBtn(P.Close, "Clear search", { onQ("") }, tint = u.dim) },
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = u.accent, unfocusedBorderColor = u.border,
            focusedTextColor = u.text, unfocusedTextColor = u.text, cursorColor = u.accent,
            focusedContainerColor = u.glassLo, unfocusedContainerColor = u.glassLo
        )
    )
}

@Composable
fun SongMenu(app: AppState, s: Song, extras: List<Pair<String, () -> Unit>> = emptyList()) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    val fav = s.id in app.prefs.favs
    Box {
        IconBtn(P.More, "More options for ${s.title}", { open = true }, tint = LocalUi.current.dim)
        DropdownMenu(open, { open = false }) {
            DropdownMenuItem(text = { Text("Play next") }, onClick = {
                open = false; app.ps.playNext(s); Toast.makeText(ctx, "Playing next", Toast.LENGTH_SHORT).show()
            })
            DropdownMenuItem(text = { Text("Add to queue") }, onClick = {
                open = false; app.ps.addToQueue(s); Toast.makeText(ctx, "Added to queue", Toast.LENGTH_SHORT).show()
            })
            DropdownMenuItem(text = { Text("Add to playlist") }, onClick = { open = false; app.pickFor = listOf(s) })
            DropdownMenuItem(text = { Text(if (fav) "Remove from favorites" else "Add to favorites") }, onClick = { open = false; app.prefs.toggleFav(s.id) })
            extras.forEach { (label, f) -> DropdownMenuItem(text = { Text(label) }, onClick = { open = false; f() }) }
        }
    }
}

@Composable
fun Collage(songs: List<Song>, sz: Dp) {
    val arts = remember(songs) { songs.distinctBy { it.albumId }.take(4) }
    if (arts.size < 4) Art(arts.firstOrNull()?.art, songs.firstOrNull()?.title ?: "Playlist", sz, 12.dp)
    else Column(Modifier.size(sz).clip(RoundedCornerShape(12.dp))) {
        for (r in 0..1) Row { for (c in 0..1) { val a = arts[r * 2 + c]; Art(a.art, a.title, sz / 2, 0.dp, plain = true) } }
    }
}

@Composable
fun Message(text: String, action: (@Composable () -> Unit)? = null) {
    Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text, color = LocalUi.current.dim, fontSize = 15.sp)
        if (action != null) { Spacer(Modifier.height(12.dp)); action() }
    }
}

@Composable
private fun TitleBlock(title: String, subtitle: String) {
    val u = LocalUi.current
    Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = u.text)
        Text(subtitle, fontSize = 13.sp, color = u.dim)
    }
}

// ───────────────────────── Playlists ─────────────────────────

@Composable
fun PlaylistsList(app: AppState, onOpen: (Detail) -> Unit) {
    val u = LocalUi.current
    var creating by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${app.pls.lists.size} playlists", color = u.dim, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Chip("New playlist", true) { creating = true }
        }
        if (app.pls.lists.isEmpty()) Message("No playlists yet. Create one, then add songs from any song’s menu.")
        LazyColumn(Modifier.fillMaxSize()) {
            items(app.pls.lists, key = { it.id }) { pl ->
                val songs = remember(pl, app.byId) { pl.songIds.mapNotNull { app.byId[it] } }
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp).clip(RoundedCornerShape(14.dp))
                        .clickable(onClickLabel = "Open ${pl.name}") { onOpen(Detail.PL(pl.id)) }.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Collage(songs, 56.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(pl.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, color = u.text)
                        Text("${pl.songIds.size} tracks", fontSize = 13.sp, color = u.dim)
                    }
                }
            }
        }
    }
    if (creating) NameDialog("New playlist", "", "Create", { app.pls.create(it); creating = false }, { creating = false })
}

@Composable
fun DetailScreen(app: AppState, d: Detail, onBack: () -> Unit) {
    val u = LocalUi.current
    val ps = app.ps
    val pl = if (d is Detail.PL) app.pls.lists.firstOrNull { it.id == d.id } else null
    if (d is Detail.PL && pl == null) { LaunchedEffect(Unit) { onBack() }; return }
    val songs = remember(d, app.songs, pl) {
        when (d) {
            is Detail.Album -> app.songs.filter { it.albumId == d.id }.sortedWith(compareBy<Song>({ it.track % 1000 }, { it.title.lowercase() }))
            is Detail.Artist -> sortSongs(app.songs.filter { it.artist == d.name }, 0)
            is Detail.PL -> pl!!.songIds.mapNotNull { app.byId[it] }
        }
    }
    val title = when (d) {
        is Detail.Album -> songs.firstOrNull()?.album?.ifBlank { "Unknown album" } ?: "Album"
        is Detail.Artist -> d.name
        is Detail.PL -> pl!!.name
    }
    val missing = if (pl != null && app.songs.isNotEmpty()) pl.songIds.size - songs.size else 0
    var rename by remember { mutableStateOf(false) }
    var delete by remember { mutableStateOf(false) }
    var picker by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(P.Back, "Back", onBack)
            Spacer(Modifier.weight(1f))
            if (pl != null) {
                var open by remember { mutableStateOf(false) }
                Box {
                    IconBtn(P.More, "Playlist options", { open = true })
                    DropdownMenu(open, { open = false }) {
                        DropdownMenuItem(text = { Text("Rename") }, onClick = { open = false; rename = true })
                        DropdownMenuItem(text = { Text("Delete playlist") }, onClick = { open = false; delete = true })
                    }
                }
            }
        }
        Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            if (pl != null) Collage(songs, 112.dp) else Art(songs.firstOrNull()?.art, title, 112.dp, 16.dp)
            Spacer(Modifier.width(16.dp))
            Column {
                Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis, color = u.text)
                Text("${songs.size} songs · ${songs.sumOf { it.durationMs } / 60000} min", fontSize = 13.sp, color = u.dim)
            }
        }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Play", true) { ps.playSongs(songs, 0, false) }
            Chip("Shuffle") { if (songs.isNotEmpty()) ps.playSongs(songs, songs.indices.random(), true) }
            if (pl != null) Chip("Add songs") { picker = true }
        }
        if (missing > 0 && pl != null) Row(Modifier.padding(horizontal = 20.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("$missing unavailable (file deleted)", color = u.dim, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Chip("Remove") { app.pls.keepOnly(pl.id, app.byId.keys) }
        }
        if (songs.isEmpty()) Message(if (pl != null) "This playlist is empty. Use “Add songs”." else "No songs.")
        LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(songs, key = { _, s -> s.id }) { i, s ->
                val extras = if (pl == null) emptyList() else buildList<Pair<String, () -> Unit>> {
                    if (i > 0) add("Move up" to { app.pls.moveTo(pl.id, s.id, songs[i - 1].id) })
                    if (i < songs.lastIndex) add("Move down" to { app.pls.moveTo(pl.id, s.id, songs[i + 1].id) })
                    add("Remove from playlist" to { app.pls.remove(pl.id, s.id) })
                }
                MusicRow(app, s, ps.current?.mediaId == s.id.toString(), { ps.playSongs(songs, i) }, extras)
            }
        }
    }
    if (pl != null && rename) NameDialog("Rename playlist", pl.name, "Rename", { app.pls.rename(pl.id, it); rename = false }, { rename = false })
    if (pl != null && delete) ConfirmDialog("Delete “${pl.name}”?", "The playlist will be removed. Your songs are not deleted.", "Delete",
        { delete = false; app.pls.delete(pl.id) }, { delete = false })
    if (pl != null && picker) SongPickerDialog(app, pl.songIds.toSet(), { ids ->
        app.pls.add(pl.id, ids); picker = false
    }, { picker = false })
}

// ───────────────────────── Settings ─────────────────────────

@Composable
private fun SettingCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val u = LocalUi.current
    Column(Modifier.fillMaxWidth().glass().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, fontWeight = FontWeight.SemiBold, color = u.text)
        content()
    }
}

@Composable
private fun SwitchRow(label: String, hint: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    val u = LocalUi.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, color = u.text)
            if (hint != null) Text(hint, fontSize = 12.sp, color = u.dim)
        }
        Switch(checked, onChange, colors = SwitchDefaults.colors(checkedTrackColor = u.accent, checkedThumbColor = u.onAccent))
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(app: AppState, onRescan: () -> Unit) {
    val u = LocalUi.current
    val prefs = app.prefs
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var confirmReset by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    ctx.contentResolver.openInputStream(uri)?.use { i -> prefs.wallpaperFile.outputStream().use { o -> i.copyTo(o) } } != null
                } catch (e: Exception) { prefs.wallpaperFile.delete(); false }
            }
            if (ok) prefs.wallpaperChanged() else Toast.makeText(ctx, "Couldn’t load that image", Toast.LENGTH_SHORT).show()
        }
    }
    var nameDialog by remember { mutableStateOf(false) }
    var cropSrc by remember { mutableStateOf<Bitmap?>(null) }
    var cropInit by remember { mutableStateOf<CropState?>(null) }
    val avatarPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val bmp = withContext(Dispatchers.IO) { decodeSampled(ctx, uri) }
            if (bmp != null) { cropInit = null; cropSrc = bmp }
            else Toast.makeText(ctx, "Couldn’t load that image. Try a JPG or PNG photo.", Toast.LENGTH_SHORT).show()
        }
    }
    val gap = Arrangement.spacedBy(8.dp)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Settings", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = u.text, modifier = Modifier.padding(horizontal = 4.dp))

        SettingCard("Theme") {
            FlowRow(horizontalArrangement = gap) { listOf("Dark", "AMOLED", "Light").forEachIndexed { i, n -> Chip(n, prefs.mode == i) { prefs.setMode(i) } } }
        }
        SettingCard("Accent color") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Accents.forEachIndexed { i, (name, c) ->
                    val sel = prefs.accent == i
                    Box(
                        Modifier.size(48.dp).clip(CircleShape)
                            .semantics { contentDescription = "$name accent"; selected = sel }
                            .clickable(role = Role.RadioButton) { prefs.setAccent(i) },
                        contentAlignment = Alignment.Center
                    ) {
                        Box(Modifier.size(34.dp).clip(CircleShape).background(c).then(if (sel) Modifier.border(3.dp, u.text, CircleShape) else Modifier))
                    }
                }
            }
            SwitchRow("Artwork colors", "Tint the app and Now Playing from the current cover. The accent above is the fallback.", prefs.dynamic) { prefs.setDynamic(it) }
            SwitchRow("Blurred cover background", "Needs Android 12+ for the blur itself.", prefs.blur) { prefs.setBlur(it) }
        }
        SettingCard("Custom background") {
            FlowRow(horizontalArrangement = gap) {
                Chip(if (prefs.wallpaperRev > 0) "Change image" else "Choose image") {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                if (prefs.wallpaperRev > 0) Chip("Remove") { prefs.clearWallpaper() }
            }
        }
        SettingCard("Profile (home greeting)") {
            Text(if (prefs.userName.isBlank()) "No name set" else "Hello, ${prefs.userName}", fontSize = 13.sp, color = u.dim)
            FlowRow(horizontalArrangement = gap) {
                Chip(if (prefs.userName.isBlank()) "Set name" else "Change name") { nameDialog = true }
                Chip(if (prefs.avatarRev > 0) "Change photo" else "Choose photo") {
                    avatarPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                if (prefs.avatarRev > 0 && AvatarStore.hasSource(ctx)) Chip("Edit photo") {
                    scope.launch {
                        val b = withContext(Dispatchers.IO) { AvatarStore.loadSource(ctx) }
                        if (b != null) { cropInit = AvatarStore.loadCrop(ctx); cropSrc = b }
                    }
                }
                if (prefs.avatarRev > 0) Chip("Remove photo") { prefs.clearAvatar(); AvatarStore.clear(ctx) }
            }
        }
        SettingCard("Seek bar style") {
            FlowRow(horizontalArrangement = gap) { listOf("Waveform", "Slider").forEachIndexed { i, n -> Chip(n, prefs.seekStyle == i) { prefs.setSeekStyle(i) } } }
            Text("Waveform bars are a visual style (stable per song), not analysed audio.", fontSize = 12.sp, color = u.dim)
        }
        SettingCard("Animation") {
            FlowRow(horizontalArrangement = gap) { listOf("Full", "Reduced", "Off").forEachIndexed { i, n -> Chip(n, prefs.motion == i) { prefs.setMotion(i) } } }
            Text("Reduced keeps short fades only. Off removes transitions, cover pulse and title scrolling.", fontSize = 12.sp, color = u.dim)
        }
        SettingCard("Now Playing artwork shape") {
            FlowRow(horizontalArrangement = gap) { listOf("Circle" to 2, "Rounded" to 0, "Square" to 1).forEach { (n, v) -> Chip(n, prefs.artShape == v) { prefs.setArtShape(v) } } }
        }
        SettingCard("Playback speed") {
            FlowRow(horizontalArrangement = gap) { speeds.forEachIndexed { i, s -> Chip("${s}x", prefs.speed == i) { prefs.setSpeed(i) } } }
        }
        SettingCard("Library") {
            Text("Default sort", fontSize = 13.sp, color = u.dim)
            FlowRow(horizontalArrangement = gap) { sorts.forEachIndexed { i, n -> Chip(n, prefs.sort == i) { prefs.setSort(i) } } }
            Chip("Rescan music (${app.songs.size} songs)", onClick = onRescan)
        }
        Chip("Restore default settings") { confirmReset = true }
        AboutCard()
        Text("FR Music Player 2.0 · your own music plays fully offline", fontSize = 12.sp, color = u.dim, modifier = Modifier.padding(horizontal = 4.dp))
        Spacer(Modifier.height(8.dp))
    }
    cropSrc?.let { b ->
        AvatarEditor(b, cropInit, { cropSrc = null }) { out, st ->
            scope.launch {
                val ok = withContext(Dispatchers.IO) { AvatarStore.save(ctx, prefs.avatarFile, b, out, st) }
                if (ok) prefs.avatarChanged() else Toast.makeText(ctx, "Couldn’t save the photo", Toast.LENGTH_SHORT).show()
                cropSrc = null
            }
        }
    }
    if (nameDialog) NameDialog("Your name", prefs.userName, "Save", { prefs.setUserName(it); nameDialog = false }, { nameDialog = false })
    if (confirmReset) ConfirmDialog("Restore defaults?", "Appearance, sort and speed return to defaults. Favorites and playlists are kept.", "Restore",
        { confirmReset = false; prefs.resetDefaults() }, { confirmReset = false })
}
