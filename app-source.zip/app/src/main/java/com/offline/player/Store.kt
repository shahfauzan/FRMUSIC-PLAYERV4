package com.offline.player

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

val speeds = listOf(0.75f, 1f, 1.25f, 1.5f, 2f)

/** Persisted preferences. Keeps the original "fr" file and keys (theme/sort/speed/blur/favs) so existing installs migrate. */
class Prefs(ctx: Context) {
    private val appCtx = ctx.applicationContext
    private val p: SharedPreferences = appCtx.getSharedPreferences("fr", Context.MODE_PRIVATE)
    val raw: SharedPreferences get() = p
    val wallpaperFile = File(appCtx.filesDir, "wallpaper.jpg")

    /** 0 Dark, 1 AMOLED, 2 Light */
    var mode by mutableIntStateOf(p.getInt("mode", 0)); private set
    /** Index into [Accents] (legacy key "theme") */
    var accent by mutableIntStateOf(p.getInt("theme", 5).coerceIn(0, Accents.lastIndex)); private set
    var sort by mutableIntStateOf(p.getInt("sort", 0).coerceIn(0, sorts.lastIndex)); private set
    var speed by mutableIntStateOf(p.getInt("speed", 1).coerceIn(0, speeds.lastIndex)); private set
    var blur by mutableStateOf(p.getBoolean("blur", true)); private set
    var dynamic by mutableStateOf(p.getBoolean("dynamic", true)); private set
    /** 0 Full, 1 Reduced, 2 Off. Defaults to Off when the system animation scale is 0. */
    var motion by mutableIntStateOf(p.getInt("motion", systemMotion())); private set
    /** Now Playing artwork: 0 Rounded, 1 Square, 2 Circle (default Circle, like the reference design) */
    var artShape by mutableIntStateOf(p.getInt("artshape", 2)); private set
    /** 0 Waveform bars, 1 Classic slider */
    var seekStyle by mutableIntStateOf(p.getInt("seekstyle", 0)); private set
    var userName by mutableStateOf(p.getString("username", "") ?: ""); private set
    val avatarFile = File(appCtx.filesDir, "avatar.jpg")
    var avatarRev by mutableIntStateOf(if (avatarFile.exists()) 1 else 0); private set
    /** songId -> number of listens (a listen = 30s or half the track, whichever is shorter) */
    var plays by mutableStateOf(loadPlays()); private set
    var wallpaperRev by mutableIntStateOf(if (wallpaperFile.exists()) 1 else 0); private set
    var favs by mutableStateOf(
        (p.getStringSet("favs", emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet()
    ); private set

    private fun loadPlays(): Map<Long, Int> = (p.getString("plays", "") ?: "").split(';').mapNotNull {
        val a = it.split(':')
        val id = a.getOrNull(0)?.toLongOrNull(); val n = a.getOrNull(1)?.toIntOrNull()
        if (id != null && n != null) id to n else null
    }.toMap()

    private fun systemMotion(): Int = try {
        if (Settings.Global.getFloat(appCtx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f) 2 else 0
    } catch (e: Exception) { 0 }

    @JvmName("applyMode") fun setMode(v: Int) { mode = v; p.edit().putInt("mode", v).apply() }
    @JvmName("applyAccent") fun setAccent(v: Int) { accent = v; p.edit().putInt("theme", v).apply() }
    @JvmName("applySort") fun setSort(v: Int) { sort = v; p.edit().putInt("sort", v).apply() }
    @JvmName("applySpeed") fun setSpeed(v: Int) { speed = v; p.edit().putInt("speed", v).apply() }
    @JvmName("applyBlur") fun setBlur(v: Boolean) { blur = v; p.edit().putBoolean("blur", v).apply() }
    @JvmName("applyDynamic") fun setDynamic(v: Boolean) { dynamic = v; p.edit().putBoolean("dynamic", v).apply() }
    @JvmName("applyMotion") fun setMotion(v: Int) { motion = v; p.edit().putInt("motion", v).apply() }
    @JvmName("applyArtShape") fun setArtShape(v: Int) { artShape = v; p.edit().putInt("artshape", v).apply() }
    @JvmName("applySeekStyle") fun setSeekStyle(v: Int) { seekStyle = v; p.edit().putInt("seekstyle", v).apply() }
    @JvmName("applyUserName") fun setUserName(v: String) { userName = v.trim(); p.edit().putString("username", userName).apply() }
    fun avatarChanged() { avatarRev = if (avatarFile.exists()) avatarRev + 1 else 0 }
    fun clearAvatar() { avatarFile.delete(); avatarChanged() }
    fun addPlay(id: Long) {
        plays = plays + (id to ((plays[id] ?: 0) + 1))
        p.edit().putString("plays", plays.entries.joinToString(";") { "${it.key}:${it.value}" }).apply()
    }
    fun wallpaperChanged() { wallpaperRev = if (wallpaperFile.exists()) wallpaperRev + 1 else 0 }
    fun clearWallpaper() { wallpaperFile.delete(); wallpaperChanged() }

    fun toggleFav(id: Long) {
        favs = if (id in favs) favs - id else favs + id
        p.edit().putStringSet("favs", favs.map { it.toString() }.toSet()).apply()
    }

    /** Restores appearance/playback preferences. Favorites, playlists and the saved session are kept. */
    fun resetDefaults() {
        p.edit().remove("mode").remove("theme").remove("sort").remove("speed").remove("blur")
            .remove("dynamic").remove("motion").remove("artshape").remove("seekstyle").apply()
        clearWallpaper()
        mode = 0; accent = 5; sort = 0; speed = 1; blur = true; dynamic = true; motion = systemMotion(); artShape = 2; seekStyle = 0
    }

    // ---- last-session restore ----
    fun saveSession(ids: String, idx: Int, pos: Long) {
        p.edit().putString("s_ids", ids).putInt("s_idx", idx).putLong("s_pos", pos).apply()
    }
    fun sessionIds(): List<Long> = (p.getString("s_ids", "") ?: "").split(',').mapNotNull { it.toLongOrNull() }
    fun sessionIdx(): Int = p.getInt("s_idx", 0)
    fun sessionPos(): Long = p.getLong("s_pos", 0L)
}

data class Playlist(val id: Long, val name: String, val songIds: List<Long>)

/** Playlists persisted as JSON inside the same preferences file. */
class PlaylistStore(private val p: SharedPreferences) {
    var lists by mutableStateOf(load()); private set

    private fun load(): List<Playlist> = try {
        val arr = JSONArray(p.getString("playlists", "[]"))
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            val ids = o.getJSONArray("ids")
            Playlist(o.getLong("id"), o.getString("name"), List(ids.length()) { ids.getLong(it) })
        }
    } catch (e: Exception) { emptyList() }

    private fun save(l: List<Playlist>) {
        lists = l
        val arr = JSONArray()
        l.forEach {
            val o = JSONObject()
            o.put("id", it.id); o.put("name", it.name); o.put("ids", JSONArray(it.songIds))
            arr.put(o)
        }
        p.edit().putString("playlists", arr.toString()).apply()
    }

    private fun update(id: Long, f: (Playlist) -> Playlist) = save(lists.map { if (it.id == id) f(it) else it })

    fun create(name: String, ids: List<Long> = emptyList()): Playlist {
        var id = System.currentTimeMillis()
        while (lists.any { it.id == id }) id++
        val pl = Playlist(id, name.trim().ifBlank { "Playlist" }, ids.distinct())
        save(lists + pl)
        return pl
    }
    fun rename(id: Long, name: String) = update(id) { it.copy(name = name.trim().ifBlank { it.name }) }
    fun delete(id: Long) = save(lists.filter { it.id != id })
    /** Returns how many tracks were actually added (duplicates are skipped). */
    fun add(id: Long, ids: List<Long>): Int {
        var added = 0
        update(id) { pl ->
            val fresh = ids.filter { it !in pl.songIds }.distinct()
            added = fresh.size
            pl.copy(songIds = pl.songIds + fresh)
        }
        return added
    }
    fun remove(id: Long, songId: Long) = update(id) { it.copy(songIds = it.songIds - songId) }
    /** Moves [fromId] to the position currently held by [toId]. */
    fun moveTo(id: Long, fromId: Long, toId: Long) = update(id) { pl ->
        val l = pl.songIds.toMutableList()
        val to = l.indexOf(toId)
        if (l.remove(fromId) && to >= 0) { l.add(to.coerceAtMost(l.size), fromId) } else return@update pl
        pl.copy(songIds = l)
    }
    fun keepOnly(id: Long, valid: Set<Long>) = update(id) { it.copy(songIds = it.songIds.filter { s -> s in valid }) }
}
